function changeH1(){
    var h1 = document.getElementById("h1-top")
    h1.innerHTML = "Yes, You Change in <h1>"
}