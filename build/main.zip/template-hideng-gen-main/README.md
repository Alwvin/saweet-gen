# This is simple template for hideng-gen
